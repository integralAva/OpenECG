#ifndef __APP_EPROM_H_
#define __APP_EPROM_H_

#include "System.h"

void EEPROM_RestartRecord(void);
void EEPROM_ECG_Record(uint8_t data);

#endif

