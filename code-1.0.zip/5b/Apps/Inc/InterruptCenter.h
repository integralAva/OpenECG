#ifndef __APP_TIC_H_
#define __APP_TIC_H_

#include "System.h"

void TimerCountout(TIM_HandleTypeDef *htim);

#endif

