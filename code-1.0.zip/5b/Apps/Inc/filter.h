#ifndef __APP_FIL_H_
#define __APP_FIL_H_

#include "System.h"



void Filter_Init(void);
void Filter_Run(void);
void Filter_Setup(float val);
void Filter_Basicline(void);

#endif

