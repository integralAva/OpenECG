#ifndef __BSP_SPI_H_
#define __BSP_SPI_H_

#include "System.h"

uint32_t SPI_Transmit32bit(uint32_t Tx);

#endif

